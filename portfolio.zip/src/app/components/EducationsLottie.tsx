'use client';
import Lottie, { LottieComponentProps } from 'lottie-react';

export function ClientLottie(props: LottieComponentProps) {

    return <Lottie {...props} />;
}