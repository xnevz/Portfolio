cd /home/potfolio
pm2 stop all
unzip portfolio.zip -d .
yarn
yarn run build
pm2 start all

- make images clickable to show the image in full size.

- add more skills and try to group them.


- implemented payment gateways for sezyshop.

- implement search.
https://www.abusaid.me/
